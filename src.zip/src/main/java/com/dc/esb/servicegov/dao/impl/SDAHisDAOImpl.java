package com.dc.esb.servicegov.dao.impl;

import org.springframework.stereotype.Repository;

import com.dc.esb.servicegov.entity.SDA;
import com.dc.esb.servicegov.entity.SDAHis;
@Repository
public class SDAHisDAOImpl extends BaseDAOImpl<SDAHis> {

}
