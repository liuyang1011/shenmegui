package com.dc.esb.servicegov.service;

import com.dc.esb.servicegov.entity.IdaPropHIS;
import com.dc.esb.servicegov.service.support.BaseService;

public interface IdaPropHISService extends BaseService<IdaPropHIS, String> {

}
