package com.dc.esb.servicegov.dao.impl;

import org.springframework.stereotype.Repository;

import com.dc.esb.servicegov.entity.ErrorCode;

@Repository
public class ErrorCodeDAOImpl extends BaseDAOImpl<ErrorCode> {
}
