package com.dc.esb.servicegov.service;

public interface ImportHandler {
	public void parse();
}
