package com.dc.esb.servicegov.dao.impl;

import org.springframework.stereotype.Repository;

import com.dc.esb.servicegov.dao.support.HibernateDAO;
import com.dc.esb.servicegov.entity.Version;
@Repository
public class VersionDAOImpl  extends HibernateDAO<Version, String>{

}
