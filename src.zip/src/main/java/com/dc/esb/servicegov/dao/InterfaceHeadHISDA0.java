package com.dc.esb.servicegov.dao;

public interface InterfaceHeadHISDA0 {

}
