package com.dc.esb.servicegov.service;

/**
 * 这个是服务的HDA管理还是接口的HDA管理
 */
public interface HdaService{

}
