package com.dc.esb.servicegov.service;

import com.dc.esb.servicegov.entity.OLATemplate;
import com.dc.esb.servicegov.service.support.BaseService;

public interface OLATemplateService extends BaseService<OLATemplate, String> {

}
