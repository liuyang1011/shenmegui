package com.dc.esb.servicegov.service;

import com.dc.esb.servicegov.entity.WorkItem;
import com.dc.esb.servicegov.service.support.BaseService;

public interface WorkItemService extends BaseService<WorkItem, String>{

}
