package com.dc.esb.servicegov.export.util;

/**
 * Created by Administrator on 2015/7/17.
 */
public class Contants {


    public final static String NAME_SPACE = "s";


    public final static String NAME_SPACE_URL = "http://esb.dcitsbiz.com/services/S120020001";
}
