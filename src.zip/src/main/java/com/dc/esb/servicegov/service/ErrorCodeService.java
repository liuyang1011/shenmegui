package com.dc.esb.servicegov.service;

import com.dc.esb.servicegov.entity.ErrorCode;
import com.dc.esb.servicegov.service.support.BaseService;


public interface ErrorCodeService extends BaseService<ErrorCode, String> {
}
