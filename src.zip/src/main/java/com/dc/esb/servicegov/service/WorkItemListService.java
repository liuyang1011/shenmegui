package com.dc.esb.servicegov.service;

import com.dc.esb.servicegov.entity.WorkItem;
import com.dc.esb.servicegov.entity.WorkItemList;
import com.dc.esb.servicegov.service.support.BaseService;

public interface WorkItemListService extends BaseService<WorkItemList, String> {

}
