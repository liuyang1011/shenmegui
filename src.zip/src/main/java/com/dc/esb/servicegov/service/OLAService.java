package com.dc.esb.servicegov.service;

import com.dc.esb.servicegov.entity.OLA;
import com.dc.esb.servicegov.service.support.BaseService;

public interface OLAService extends BaseService<OLA, String> {

}
