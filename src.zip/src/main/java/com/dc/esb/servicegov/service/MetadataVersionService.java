package com.dc.esb.servicegov.service;

/**
 * Created by Administrator on 2015/12/31.
 */
public interface MetadataVersionService {
}
