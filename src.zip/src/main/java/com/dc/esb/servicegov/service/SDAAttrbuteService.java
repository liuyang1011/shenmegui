package com.dc.esb.servicegov.service;

import com.dc.esb.servicegov.dao.support.SearchCondition;
import com.dc.esb.servicegov.entity.EnumElementMap;
import com.dc.esb.servicegov.entity.EnumElements;
import com.dc.esb.servicegov.entity.MasterSlaveEnumMap;
import com.dc.esb.servicegov.entity.SGEnum;

import java.util.HashMap;
import java.util.List;


public interface SDAAttrbuteService {
}
