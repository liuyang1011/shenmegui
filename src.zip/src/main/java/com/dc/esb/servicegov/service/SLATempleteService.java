package com.dc.esb.servicegov.service;

import com.dc.esb.servicegov.entity.SLATemplate;
import com.dc.esb.servicegov.entity.SLATemplete;
import com.dc.esb.servicegov.service.support.BaseService;

public interface SLATempleteService extends BaseService<SLATemplate, String> {

}
