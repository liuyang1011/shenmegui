package com.dc.esb.servicegov.util;

/**
 * Created by vincentfxz on 15/9/22.
 *
 * 交易链路 链接线的VO
 *
 */
public class GraphConnection {

    private String source;
    private String target;

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getTarget() {
        return target;
    }

    public void setTarget(String target) {
        this.target = target;
    }
}
