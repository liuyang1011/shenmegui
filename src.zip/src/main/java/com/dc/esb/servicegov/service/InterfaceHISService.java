package com.dc.esb.servicegov.service;

import com.dc.esb.servicegov.entity.InterfaceHIS;
import com.dc.esb.servicegov.service.support.BaseService;

public interface InterfaceHISService extends BaseService<InterfaceHIS, String> {

}
