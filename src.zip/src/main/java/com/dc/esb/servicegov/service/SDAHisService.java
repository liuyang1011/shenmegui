package com.dc.esb.servicegov.service;

import com.dc.esb.servicegov.entity.SDAHis;
import com.dc.esb.servicegov.service.support.BaseService;

public interface SDAHisService extends BaseService<SDAHis, String> {

}
