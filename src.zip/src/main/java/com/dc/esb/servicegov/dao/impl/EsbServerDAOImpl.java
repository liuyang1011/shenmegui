package com.dc.esb.servicegov.dao.impl;

import com.dc.esb.servicegov.dao.support.HibernateDAO;
import com.dc.esb.servicegov.entity.EsbServer;
import org.springframework.stereotype.Repository;

/**
 * Created by Administrator on 2016/1/20.
 */
@Repository
public class EsbServerDAOImpl extends HibernateDAO<EsbServer, String> {
}
