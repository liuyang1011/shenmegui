package com.dc.esb.servicegov.dao;

/**
 * Created by Administrator on 2015/12/15.
 */
public interface UserSystemRelationDAO {
}
