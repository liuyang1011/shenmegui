package com.dc.esb.servicegov.service;

import com.dc.esb.servicegov.entity.SGUser;
import com.dc.esb.servicegov.service.support.BaseService;

/**
 * Created by vincentfxz on 15/7/4.
 */
public interface UserService extends BaseService<SGUser,String> {

}
