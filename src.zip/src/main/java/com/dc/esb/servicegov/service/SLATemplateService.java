package com.dc.esb.servicegov.service;

import com.dc.esb.servicegov.entity.SLATemplate;
import com.dc.esb.servicegov.service.support.BaseService;


public interface SLATemplateService extends BaseService<SLATemplate, String> {

}
