package com.dc.esb.servicegov.service;

import com.dc.esb.servicegov.entity.CorrelationPropertyInfo;
import com.dc.esb.servicegov.service.support.BaseService;

public interface CorrelationPropertyInfoService extends
		BaseService<CorrelationPropertyInfo, String> {

}
