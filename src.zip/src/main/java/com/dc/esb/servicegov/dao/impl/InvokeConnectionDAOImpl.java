package com.dc.esb.servicegov.dao.impl;

import com.dc.esb.servicegov.dao.support.HibernateDAO;
import com.dc.esb.servicegov.entity.InvokeConnection;
import org.springframework.stereotype.Repository;

/**
 * Created by vincentfxz on 15/7/13.
 */
@Repository
public class InvokeConnectionDAOImpl extends HibernateDAO<InvokeConnection, String>{
}
