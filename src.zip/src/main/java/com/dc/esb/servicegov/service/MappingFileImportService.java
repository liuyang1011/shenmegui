package com.dc.esb.servicegov.service;

/**
 * Created by Administrator on 2015/11/16.
 */
public interface MappingFileImportService {
}
