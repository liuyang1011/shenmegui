package com.dc.esb.servicegov.service;

import com.dc.esb.servicegov.entity.InterfaceInvoke;
import com.dc.esb.servicegov.service.support.BaseService;

/**
 * Created by jiangqi on 2015/8/10.
 */
public interface InterfaceInvokeService extends BaseService<InterfaceInvoke, String> {

}
