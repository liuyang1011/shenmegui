package com.dc.esb.servicegov.service;

import com.dc.esb.servicegov.entity.SLA;
import com.dc.esb.servicegov.service.support.BaseService;

public interface SLAService extends BaseService<SLA, String> {

}
