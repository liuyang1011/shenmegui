package com.dc.esb.servicegov.service;

import com.dc.esb.servicegov.entity.ServiceCategoryHis;
import com.dc.esb.servicegov.service.support.BaseService;

public interface ServiceCategoryHisService extends BaseService<ServiceCategoryHis, String> {

}
