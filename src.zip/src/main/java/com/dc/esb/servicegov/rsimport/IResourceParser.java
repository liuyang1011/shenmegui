package com.dc.esb.servicegov.rsimport;

import org.apache.poi.ss.usermodel.Workbook;

public interface IResourceParser {
	public void parse(Workbook workbook) ;

}
