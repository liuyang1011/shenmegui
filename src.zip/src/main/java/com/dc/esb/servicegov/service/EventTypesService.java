package com.dc.esb.servicegov.service;

import com.dc.esb.servicegov.entity.EventTypes;
import com.dc.esb.servicegov.service.support.BaseService;

public interface EventTypesService extends BaseService<EventTypes, String> {

}
