package com.dc.esb.servicegov.dao.impl;

import com.dc.esb.servicegov.dao.support.HibernateDAO;
import com.dc.esb.servicegov.entity.SDAPropHis;
import org.springframework.stereotype.Repository;

/**
 * Created by vincentfxz on 15/6/29.
 */
@Repository
public class SDAPropHisDAOImpl extends HibernateDAO<SDAPropHis, String>{

}
