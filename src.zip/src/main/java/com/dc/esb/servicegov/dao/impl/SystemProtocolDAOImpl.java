package com.dc.esb.servicegov.dao.impl;

import org.springframework.stereotype.Repository;

import com.dc.esb.servicegov.entity.SystemProtocol;

@Repository
public class SystemProtocolDAOImpl extends BaseDAOImpl<SystemProtocol> {

}
