package com.dc.esb.servicegov.export.exception;

/**
 * Created by vincentfxz on 15/11/24.
 */
public class ExportException extends Exception{
    public ExportException(String s) {
        super(s);
    }
}
