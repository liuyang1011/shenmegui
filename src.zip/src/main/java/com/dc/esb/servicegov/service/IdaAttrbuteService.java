package com.dc.esb.servicegov.service;


public interface IdaAttrbuteService {
}
