package com.dc.esb.servicegov.service;

import com.dc.esb.servicegov.entity.CorrelationKeyInfo;
import com.dc.esb.servicegov.service.support.BaseService;

public interface CorrelationKeyInfoService extends BaseService<CorrelationKeyInfo,String> {

}
