package com.dc.esb.servicegov.service;


import com.dc.esb.servicegov.entity.IdaHIS;
import com.dc.esb.servicegov.service.support.BaseService;

public interface IdaHISService extends BaseService<IdaHIS, String>{

}
