package com.dc.esb.servicegov.service;

import com.dc.esb.servicegov.entity.UserSystemRelation;
import com.dc.esb.servicegov.service.support.BaseService;

/**
 * Created by Administrator on 2015/12/15.
 */
public interface UserSystemRelationService   extends BaseService<UserSystemRelation,String> {
}
